package Lec_03;

import java.util.Scanner;

public class input {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("A");
		int x = scn.nextInt();
		int y = scn.nextInt();
		int z = scn.nextInt();
		
		System.out.println("B");
		System.out.println(x+y+z);
		
	}
}
