package Lec_01;

public class ifelse_demo {
	public static void main(String[] args) {
		System.out.println(15 / 2); // Que
		System.out.println(15 % 2); // rem
	}
}
