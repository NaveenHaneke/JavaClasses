package Lec_01;

public class demo2 {
	public static void main(String[] args) {
		System.out.println("jo likhna hai likho!");
		System.out.println("jaldi aao");
		System.out.println("C");
	}
}
