package Lec_01;

public class Simple_Int {
	public static void main(String[] args) {
		int A = 1000;
		int D = 20;
		int ROI = 10;
		
		int ans = A*ROI*D/100;
		System.out.println(ans);
	}
}
