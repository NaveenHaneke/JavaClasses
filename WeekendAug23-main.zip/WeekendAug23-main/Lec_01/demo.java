package Lec_01;

public class demo {

	public static void main(String[] args) {
		int i = 5+10;
		int i2 = 5+10;
		int i3 = 5+10;
		
		System.out.println(i);
		System.out.println("i");
		System.out.println("done");
		System.out.println(i+i2*i3);
	}

}
