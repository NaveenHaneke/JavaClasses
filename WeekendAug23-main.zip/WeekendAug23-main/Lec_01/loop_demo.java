package Lec_01;

public class loop_demo {
	public static void main(String[] args) {
		int cnt = 1;
		while (cnt <= 5) {
			System.out.println("baja!");
			cnt = cnt + 1;
		}
		System.out.println(cnt);
	}
}
