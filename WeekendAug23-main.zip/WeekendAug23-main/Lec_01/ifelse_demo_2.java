package Lec_01;

public class ifelse_demo_2 {
	public static void main(String[] args) {
		int var = 10;
		if(var%2==0){
			System.out.println("even");
		}else {
			System.out.println("odd");
		}
	}
}
