package Lec_07;

public class for_loop {
	public static void main(String[] args) {
//		int i = 1; //I
//		while (i <= 5) { //C
//
//			System.out.println(i); // Work
//			i++; // Update!!
//		}
		int i=1;
		for(;i<=5;) {
			System.out.println(i);
			i++;			
		}
		System.out.println(i);
		 
	}
}
