package Lec_07;

public class data_type_demo {
	public static void main(String[] args) {
		byte b = (byte)261;
		System.out.println(b);

		short s = 32767;
		System.out.println(s);

		int i = 2147483647;
		System.out.println(i);
		System.out.println(Integer.MIN_VALUE);

		long l = 1000000;
		System.out.println(l);

	}

}
