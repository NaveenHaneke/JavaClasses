package Lec_02;

public class counting {
	public static void main(String[] args) {
//		System.out.println("done");
		int n = 5;
		int cnt = 0;
		while (cnt <= n) {
			System.out.println(cnt);
			cnt = cnt + 1;
		}
	}
}  
