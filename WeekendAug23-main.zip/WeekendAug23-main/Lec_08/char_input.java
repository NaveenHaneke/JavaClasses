package Lec_08;

import java.util.Scanner;

public class char_input {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		char ch = scn.next().charAt(3);
		System.out.println(ch);
	}
}
