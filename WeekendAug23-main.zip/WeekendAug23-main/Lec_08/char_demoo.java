package Lec_08;

public class char_demoo {
	public static void main(String[] args) {
		char ch = 'a';
		
		int i = ch+1;
		System.out.println(i+" <= ");
		System.out.println(ch+99);
		System.out.println((int)ch);
		System.out.println((int)'^');
		
		System.out.println((char)19900);
		
	}
}
