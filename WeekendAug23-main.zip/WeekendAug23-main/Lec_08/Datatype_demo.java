package Lec_08;

public class Datatype_demo {
	public static void main(String[] args) {
//		boolean b = 2==5;
//		System.out.println(b);
//		while(b) {
//			System.out.println("aag");
//		}
		
		float f = (float)2.5;
		double d = 2.5;
		
	}
}
